<?php get_header(); ?>

	<?php get_template_part('includes/breadcrumbs'); ?>

	<div id="left-area">
		<?php get_template_part('includes/entry'); ?>
	</div> 	<!-- end #left-area -->

	<?php get_sidebar(); ?>

<?php get_footer(); ?>
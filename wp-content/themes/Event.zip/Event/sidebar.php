<div id="sidebar">
	<div id="sidebar-bottom">
		<div id="sidebar-content">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>
			<?php endif; ?>
		</div> <!-- end #sidebar-content -->
	</div> <!-- end #sidebar-bottom -->
</div> <!-- end #sidebar -->